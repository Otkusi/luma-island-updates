﻿$ErrorActionPreference = 'Stop'
# Compatibility entry: create a verified new folder; never overwrite a locked exe.
& (Join-Path $PSScriptRoot 'Install-Luma-NewFolder.ps1')
exit $LASTEXITCODE
