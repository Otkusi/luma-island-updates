﻿[CmdletBinding()]
param([string]$SourceDirectory = '', [string]$PayloadDirectory = '', [string]$DestinationRoot = '', [string]$ReceiptPath = '')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$source = if ($SourceDirectory) { $SourceDirectory } else { $PSScriptRoot }
$installerRoot = $PSScriptRoot
$destination = $null
$complete = $false
function Hash-File([string]$file) { (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() }
try {
    $payload = if ($PayloadDirectory) { $PayloadDirectory } else { Join-Path $installerRoot 'update-payload' }
    $manifest = Get-Content -LiteralPath (Join-Path $payload 'manifest.json') -Raw | ConvertFrom-Json
    $version = [string]$manifest.version
    if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Некорректная версия обновления.' }
    if (-not (Test-Path -LiteralPath (Join-Path $source 'Luma Island.exe'))) {
        if ($SourceDirectory) { throw 'Не найдена исходная папка приложения.' }
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.FolderBrowserDialog
        $picker.Description = 'Выберите прежнюю папку с Luma Island.exe'
        $picker.ShowNewFolderButton = $false
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
        $source = $picker.SelectedPath
        $picker.Dispose()
    }
    $exe = Join-Path $source 'Luma Island.exe'
    $originalHash = Hash-File $exe
    $base = @($manifest.bases | Where-Object { $_.sha256 -eq $originalHash }) | Select-Object -First 1
    if ($originalHash -ne $manifest.newExeSha256 -and -not $base) { throw 'Исходный exe не распознан. Сохраните резервные копии Luma-backup и сообщите об этой ошибке.' }
    if ((Hash-File (Join-Path $payload 'app.asar')) -ne $manifest.asarSha256 -or
        (Hash-File (Join-Path $payload 'Island.Native.exe')) -ne $manifest.nativeSha256) { throw 'Файлы обновления повреждены. Распакуйте полный ZIP обновления заново.' }
    $runtime = @('LICENSE.electron.txt','LICENSES.chromium.html','chrome_100_percent.pak','chrome_200_percent.pak','d3dcompiler_47.dll','dxcompiler.dll','dxil.dll','ffmpeg.dll','icudtl.dat','libEGL.dll','libGLESv2.dll','resources.pak','snapshot_blob.bin','v8_context_snapshot.bin','vk_swiftshader.dll','vk_swiftshader_icd.json','vulkan-1.dll')
    foreach ($name in $runtime) { if (-not (Test-Path -LiteralPath (Join-Path $source $name))) { throw ('Не найден файл приложения: '+$name+'. Распакуйте установщик в папку с Luma Island.exe.') } }
    if (-not (Test-Path -LiteralPath (Join-Path $source 'locales'))) { throw 'Не найдена папка locales.' }
    $bytes = [IO.File]::ReadAllBytes($exe)
    if ($bytes.Length -ne $manifest.newExeLength) { throw 'Размер исходного exe не совпал.' }
    if ($originalHash -ne $manifest.newExeSha256) {
        foreach ($patch in $base.patches) {
            $replacement = [Convert]::FromBase64String($patch.data)
            [Array]::Copy($replacement,0,$bytes,[int]$patch.offset,$replacement.Length)
        }
    }
    $parent = if ($DestinationRoot) { $DestinationRoot } else { $source }
    $destination = Join-Path $parent ('Luma-'+$version+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path (Join-Path $destination 'resources/native') -Force | Out-Null
    Write-Host 'Создаю обновлённый остров в новой папке. Исходные файлы не заменяются...'
    foreach ($name in $runtime) { Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $destination $name) }
    Copy-Item -LiteralPath (Join-Path $source 'locales') -Destination (Join-Path $destination 'locales') -Recurse
    Copy-Item -LiteralPath (Join-Path $payload 'app.asar') -Destination (Join-Path $destination 'resources/app.asar')
    Copy-Item -LiteralPath (Join-Path $payload 'Island.Native.exe') -Destination (Join-Path $destination 'resources/native/Island.Native.exe')
    $newExe = Join-Path $destination 'Luma Island.exe'
    [IO.File]::WriteAllBytes($newExe,$bytes)
    if ((Hash-File $newExe) -ne $manifest.newExeSha256 -or
        (Hash-File (Join-Path $destination 'resources/app.asar')) -ne $manifest.asarSha256 -or
        (Hash-File (Join-Path $destination 'resources/native/Island.Native.exe')) -ne $manifest.nativeSha256) { throw 'Проверка новой папки не прошла.' }
    if ($ReceiptPath) {
        $receipt = @{version=$version; exePath=$newExe; exeSha256=$manifest.newExeSha256; asarSha256=$manifest.asarSha256; nativeSha256=$manifest.nativeSha256; sourceExe=$exe}
        [IO.File]::WriteAllText($ReceiptPath,($receipt | ConvertTo-Json -Compress),(New-Object System.Text.UTF8Encoding($false)))
    }
    $complete = $true
    Write-Host 'Готово! Новая версия находится здесь:' -ForegroundColor Green
    Write-Host $destination
    Write-Host 'Закройте прежний остров через трей, затем откройте Luma Island.exe из НОВОЙ папки. Настройки сохраняются.'
    Write-Host 'Если прежний процесс не закрывается, перезагрузите компьютер перед запуском новой версии.'
    exit 0
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($destination -and -not $complete) { Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction SilentlyContinue }
    exit 1
}
